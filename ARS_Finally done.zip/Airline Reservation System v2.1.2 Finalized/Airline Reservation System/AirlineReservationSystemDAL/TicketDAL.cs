﻿//<Summary>
/*********************************************************************
 * File                 : TicketDAL.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 22-Dec-2019
 *********************************************************************/
//</Summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;
using System.Data.SqlClient;
using System.Configuration;
namespace AirlineReservationSystemDAL
{
    public class TicketDAL
    {

        //Declaring SqlConnection object reference
        SqlConnection con = null;

        //Declaring SqlCommand object reference
        SqlCommand cmd = null;

        //Declaring Data Reader object reference
        SqlDataReader dr = null;

        public TicketDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        }

        //DAL Method to Select ticket from reservation table

        public Reservation ViewTicketDAL(string ticketNo)
        {
            Reservation ticket = new Reservation();
            try
            {
                cmd = new SqlCommand("airline.USP_VIEWRESERVATION", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ticketNo", ticketNo);
                con.Open();

                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {

                        ticket.TicketNo = dr[1].ToString();
                        ticket.FlightId = dr[2].ToString();
                        ticket.DateofBooking = dr[3].ToString();
                        ticket.JourneyDate = dr[4].ToString();
                        ticket.PassengerName = dr[5].ToString();
                        ticket.Age = Convert.ToInt32(dr[6]);
                        ticket.Gender = dr[7].ToString();
                        ticket.ContactNo = dr[8].ToString();
                        ticket.Email = dr[9].ToString();
                        ticket.Class = dr[10].ToString();
                        ticket.NoofTickets = Convert.ToInt32(dr[11]);
                        ticket.TotalFare = Convert.ToDecimal(dr[12]);
                        ticket.Status = dr[13].ToString();
                    }
                }
                dr.Close();

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return ticket;
        }

        //This is method to book ticket (not completed)
        public string BookTicketDAL(Reservation ticket)
        {
            string ticketNo = null;
            try
            {
                
                    decimal fare = getFare(ticket.Class, ticket.FlightId);
                    decimal totalFare = fare * ticket.NoofTickets;
                    cmd = new SqlCommand("airline.USP_RESERVATIONINSERT", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@flightID ", ticket.FlightId);
                    cmd.Parameters.AddWithValue("@dateofBooking ", ticket.DateofBooking);
                    cmd.Parameters.AddWithValue("@journeyDate ", ticket.JourneyDate);
                    cmd.Parameters.AddWithValue("@passengerName ", ticket.PassengerName);
                    cmd.Parameters.AddWithValue("@age ", ticket.Age);
                    cmd.Parameters.AddWithValue("@gender ", ticket.Gender);
                    cmd.Parameters.AddWithValue("@contacNo ", ticket.ContactNo);
                    cmd.Parameters.AddWithValue("@email ", ticket.Email);
                    cmd.Parameters.AddWithValue("@class", ticket.Class);
                    cmd.Parameters.AddWithValue("@totalFare ", totalFare);
                    cmd.Parameters.AddWithValue("@noofTickets", ticket.NoofTickets);
                    cmd.Parameters.AddWithValue("@reservationStatus", "Booked");
                    con.Open();

                    cmd.ExecuteNonQuery();
                    con.Close();

                    ticketNo = getTicketNo();
                
            }

            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return ticketNo;

        }
        
        //DAL Method to get fare of class for particular flight 
        public decimal getFare(string flightClass,string flightId)
        {
            cmd = new SqlCommand("Select fare from airline.FlightClass where FlightId=@flightId and Class=@flightClass", con);
            
            cmd.Parameters.AddWithValue("@flightId",flightId);
            cmd.Parameters.AddWithValue("@flightClass", flightClass.ToString());

            con.Open();
            string fare = cmd.ExecuteScalar().ToString();
            con.Close();
            return Convert.ToDecimal(fare);
            //  Console.WriteLine(fare);
        }

        //DAL Method to get Ticket No.
        public string getTicketNo()
        {


            cmd = new SqlCommand("Select max(TicketNo) from airline.reservation", con);
            con.Open();
            string ticketNo = cmd.ExecuteScalar().ToString();
            //string ticketNo = "CG" + (10000000 + ticketNumber);
            con.Close();
            return ticketNo;
        }

        //DAL Method to validate Admin Login
        public bool LoginUserDAL(string userName, string password)
        {
            bool userFound = false;
            try
            {

                SqlCommand cmd = new SqlCommand("[airline].[USP_USERSEARCH]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@userName", userName);
                cmd.Parameters.AddWithValue("@password", password);
                con.Open();

                if (cmd.ExecuteScalar().ToString() == "1")
                {
                    userFound = true;
                }
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return userFound;

        }

        //DAL Method to check number of seats available
        public bool CheckSeats(string flightID, string flightClass,string journeyDate,int noOfPassengers)
        {
            bool seatsAvailable = false;
            try
            {

                SqlCommand cmd = new SqlCommand("[airline].[USP_CLASSBOOKING]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@flightID", flightID);
                cmd.Parameters.AddWithValue("@flightClass", flightClass.ToString());
                cmd.Parameters.AddWithValue("@journeyDate", Convert.ToDateTime(journeyDate).Date);
                cmd.Parameters.AddWithValue("@noOfPassengers", noOfPassengers);

                cmd.Parameters.Add("@retValue", System.Data.SqlDbType.Int).Direction = System.Data.ParameterDirection.ReturnValue;
                
                con.Open();
                cmd.ExecuteNonQuery();
                int retval = (int)cmd.Parameters["@retValue"].Value;

                //if (cmd.ExecuteScalar().ToString() == "1")
                if (retval.ToString() == "1")
                {
                    seatsAvailable = true;
                }
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return seatsAvailable;

        }

        //DAL Method for ticket Cancellation
        public bool CancelTicketDAL(string TicketNo)
        {
            bool isCancelled = false;
            try
            {
                SqlCommand cmd = new SqlCommand("[airline].[USP_CancelTicket]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ticketNo", TicketNo);
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                    isCancelled = true;
            }
            catch(AirlineException ae)
            {
                throw ae;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return isCancelled;
            
        }


    }
}
