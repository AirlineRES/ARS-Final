﻿//<Summary>
/*********************************************************************
 * File                 : FlightFare.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 10-Dec-2019
 *********************************************************************/
//</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystemEntities
{
    // Class to create the properties of FlightFare class

    public class FlightFare
    {
        public int FlightId { get; set; }
        public decimal Fare { get; set; }
        public int seats { get; set; }
        public string FlightClass { get; set; }

    }
}
