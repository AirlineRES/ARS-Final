﻿//<Summary>
/*********************************************************************
 * File                 : FlightRevenue.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 10-Dec-2019
 *********************************************************************/
//</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystemEntities
{
    // Class to create the properties of FlightRevenue class

    public class FlightRevenue
    {
       
        private int _id;
        public int flightID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        private int _total;
        public int TotalRevenue
        {
            get
            {
                return _total;
            }
            set

            {
                _total = value;
            }
        }
    }
}
