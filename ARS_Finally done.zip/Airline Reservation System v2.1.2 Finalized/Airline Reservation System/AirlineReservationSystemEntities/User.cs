﻿//<Summary>
/*********************************************************************
 * File                 : RevenueOverall.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 10-Dec-2019
 *********************************************************************/
//</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystemEntities
{
    // Class to create the properties of User class
    public class User
    {
        int Id { get; set; }
        string UserName { get; set; }
        string UserPassword { get; set; }
    }
}
