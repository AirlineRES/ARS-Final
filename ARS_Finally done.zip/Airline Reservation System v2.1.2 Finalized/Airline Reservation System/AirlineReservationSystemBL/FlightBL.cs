﻿//<Summary>
/*********************************************************************
 * File                 : FlightBL.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 27-Dec-2019
 *********************************************************************/
//</Summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemDAL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;

namespace AirlineReservationSystemBL
{
    public class FlightBL
    {
        // BL Method to validate user input
        private static bool IsInputValid(Flight flight)
        {
            StringBuilder sb = new StringBuilder();
            bool validFlight = true;
      
            if (flight.FlightID.ToString().Length < 5) 
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Flight Id should be of 5 digits");

            }
            if (flight.LaunchDate < DateTime.Now)
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Launch Date Invalid");

            }

            if (flight.Destination.Length<2)
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Destination Invalid");

            }

            if (flight.DeptTime.ToString() == " ")
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Departure time Invalid");

            }

            if (flight.ArrivalTime.ToString() == " ")
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "Arrival time  Invalid");

            }
            if (flight.NoOfSeats < 0)
            {
                validFlight = false;
                sb.Append(Environment.NewLine + "No of seats Invalid");

            }

            if (validFlight == false)
                throw new AirlineException(sb.ToString());

            return validFlight;
        }

        //BL Method to insert data in Flight table 
        public static bool InsertFlightBL(Flight flight)
        {
            bool isInserted = false;
            try
            {
                if (IsInputValid(flight))
                {
                    FlightDAL flightDAL = new FlightDAL();
                    isInserted = flightDAL.InsertFlightDAL(flight);

                }

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception)
            {
                throw;
            }

            return isInserted;
        }


        //BL Method to insert data in Flight class table 
        public static bool InsertFlightClassBL(int flightId , int fClassSeats = 0, decimal fClassFare=0, int EClassSeats = 0, decimal EClassFare = 0, int BClassSeats = 0, decimal BClassFare = 0,int noOfSeats = 0)
        {
            bool isInserted = false;
            try
            {
                //if (IsInputValid(flight))
                //  {
                if (noOfSeats==fClassSeats+EClassSeats+BClassSeats)
                {

                    FlightDAL flightDAL = new FlightDAL();
                    isInserted = flightDAL.InsertFlightClassDAL(flightId, fClassSeats, fClassFare, EClassSeats, EClassFare, BClassSeats, BClassFare);

                }
                else
                    throw new AirlineException("Seats not inserted properly");
                //   }

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception)
            {
                throw;
            }

            return isInserted;
        }


        //BL Method to delete data in Flight table 
        public static bool DeleteFlightBL(int flightId)
        {
            bool isDeleted = false;
            try
            {
                if (flightId > 0)
                {
                    FlightDAL flightDAL = new FlightDAL();
                    isDeleted = flightDAL.DeleteFlightDAL(flightId);

                }

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return isDeleted;
        }
        //BL Method to Select flights
        public static IEnumerable<Flight> ViewFlightsBL(string source,string destination)
        {
            IEnumerable<Flight> flights = null;
            try
            {

                FlightDAL flightDAL = new FlightDAL();
                flights = flightDAL.ViewFlightsDAL(source, destination);

            }
        
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return flights;
        }


        //BL Method to get total revenue
        public static FlightRevenue TotalRevenueBL(int fid)
        {
            FlightRevenue flightRevenue = null;
            try
            {
                FlightDAL revDAL = new FlightDAL();
                flightRevenue = revDAL.TotalRevenueDAL(fid);
                // rev = revDAL.SelectAllDAL(fid);
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return flightRevenue;

        }

        //
        //BL Method to get flight classes
        public static IEnumerable<FlightFare> GetFlightClass(int flightId)
        {
            IEnumerable<FlightFare> flightFareList = null;
            try
            {

                FlightDAL flightDAL = new FlightDAL();
                flightFareList = flightDAL.GetFlightClass(flightId);

            }

            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return flightFareList;
        }

    }
}
