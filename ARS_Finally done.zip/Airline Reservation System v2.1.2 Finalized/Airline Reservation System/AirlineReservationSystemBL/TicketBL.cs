﻿//<Summary>
/*********************************************************************
 * File                 : TicketBL.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 27-Dec-2019
 *********************************************************************/
//</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemDAL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;

namespace AirlineReservationSystemBL
{
    public class TicketBL
    {
        // BL Method to validate user input
        private static bool IsInputValid(Reservation reserv)
        {
            StringBuilder sb = new StringBuilder();
            bool validBookingEntry = true;

            if (reserv.FlightId.Length < 2)
            {
                validBookingEntry = false;
                sb.Append(Environment.NewLine + "Flight ID entered is Invalid");

            }

            if (Convert.ToDateTime(reserv.DateofBooking).Date != DateTime.Now.Date)
            {
                validBookingEntry = false;
                sb.Append(Environment.NewLine + "Date of booking can not be after today's date.");

            }

            if (Convert.ToDateTime( reserv.JourneyDate).Date <= DateTime.Now.Date)
            {
                validBookingEntry = false;
                sb.Append(Environment.NewLine + "Journey date can not be before than today's date.");

            }

            if (reserv.PassengerName == "[A-za-z ]")
            {
                validBookingEntry = false;
                sb.Append(Environment.NewLine + "Customer name is not valid");
            }

            if (reserv.ContactNo.Length != 10)
            {
                validBookingEntry = false;
                sb.Append(Environment.NewLine + "Please enter a Contact Number of 10 digits only.");

            }

            //if (reserv.ContactNo != "[0-9]{10}")
            //{
            //    validBookingEntry = false;
            //    sb.Append(Environment.NewLine + "Please enter a valid contact number");
            //}

            string email = reserv.Email;
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            System.Text.RegularExpressions.Match match = regex.Match(email);

            if (match.Success)
            {
                validBookingEntry = true;
            }
            else
            {
                validBookingEntry = false;
                sb.Append(Environment.NewLine + "Email ID entered is not valid.");
            }

            if (reserv.NoofTickets < 0 || reserv.NoofTickets > 6)
            {
                validBookingEntry = false;
                sb.Append(Environment.NewLine + "Please enter a number from 1 to 6.");
            }


            if (reserv.Age < 0 || reserv.Age > 120)
            {
                validBookingEntry = false;
                sb.Append(Environment.NewLine + "Please enter valid Age.");
            }

            if (validBookingEntry == false)
                throw new AirlineException(sb.ToString());

            return validBookingEntry;
        }

        // BL Method to view the ticket
        public static Reservation ViewTicketBL(string ticketNo)
        {
            Reservation ticket = null;
            try
            {
                
                TicketDAL ticketDAL = new TicketDAL();
                ticket = ticketDAL.ViewTicketDAL(ticketNo);

            }

            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ticket;
        }

        // BL Method to Admin login
        public static bool LoginUserBL(string userName, string password)
        {
            bool userFound = false;
            try
            {
                if (userName != null && password != null)
                {
                    TicketDAL ticketDAL = new TicketDAL();
                    userFound = ticketDAL.LoginUserDAL(userName, password);

                }
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userFound;

        }

        // BL Method to Book Ticket
        public static string BookTicketBL(Reservation ticket)
        {
            string ticketNo = null;
            try
            {
                if (IsInputValid(ticket))
                { 
                    TicketDAL ticketDAl = new TicketDAL();
                    if (ticketDAl.CheckSeats(ticket.FlightId, ticket.Class,ticket.JourneyDate,ticket.NoofTickets))
                    {
                        ticketNo = ticketDAl.BookTicketDAL(ticket);
                    }
                    else
                        ticketNo = "NA";
                }
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ticketNo;
        }

        // BL Method to Cancel ticket
        public static bool CancelTicketBL(string TicketNo)
        {
           bool isCancelled = false;
            try
            {
                TicketDAL ticketDAL = new TicketDAL();
                isCancelled= ticketDAL.CancelTicketDAL(TicketNo);
            }
            catch(AirlineException ae)
            {
                throw ae;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return isCancelled;

        }
    }
}
