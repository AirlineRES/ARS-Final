﻿//<Summary>
/*********************************************************************
 * File                 : ViewTicket.xaml.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 29-Dec-2019
 *********************************************************************/
//</Summary>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for ViewTicket.xaml
    /// </summary>
    public partial class ViewTicket : Window
    {
        public ViewTicket()
        {
            InitializeComponent();
        }

        //validation for user input
        public bool Validation()
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;

            if (txtTicketID.Text.Length == 0)
            {
               sb.Append("Please Enter Ticket Id...!!!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new Exception(sb.ToString());
            }

            return isValid;
        }

        //close window event
        private void ArsCancel_Click(object sender, RoutedEventArgs e)
        {
            HomePage objHome = new HomePage();
            objHome.Show();
            this.Close();
        }

        //button click event for search ticket
        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Validation())
                {
                    // for displaying ticket
                    Reservation res = null;
                    res = TicketBL.ViewTicketBL(txtTicketID.Text.ToString());
                    IEnumerable<Reservation> resa = new List<Reservation> { res };
                    dgViewTicket.ItemsSource = resa;
                }
            }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //button click event for cancel flight
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool cancelledPL = false;
                if (Validation())
                {
                    
                    string ticketNo;
                    ticketNo = txtTicketID.Text;
                    cancelledPL = TicketBL.CancelTicketBL(ticketNo);
                }
                if(cancelledPL)
                {
                    MessageBox.Show("Your Ticket is Cancelled");
                }
                else
                {
                    MessageBox.Show("Yoyr Ticket is not Cancelled");
                }
            }
            catch(AirlineException ae)
            {
                throw ae;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        //hyperlink event for home window
        private void Hyperlink_Home(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            HomePage homePage = new HomePage();
            homePage.Show();
            this.Close();
        }
    }
}
