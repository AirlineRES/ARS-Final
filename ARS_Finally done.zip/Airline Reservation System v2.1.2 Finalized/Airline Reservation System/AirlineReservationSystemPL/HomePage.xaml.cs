﻿//<Summary>
/*********************************************************************
 * File                 : HomePage.xaml.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 29-Dec-2019
 *********************************************************************/
//</Summary>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Window
    {
        IEnumerable<Flight> flights = null;

        public HomePage()
        {
            InitializeComponent();
        }

        //validation for user input
        public bool Validation()
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;

            if (dpTravelDate.Text.Length == 0)
            {
                isValid = false;
                sb.Append("Please Enter Travel Date");
            }

            //if (dpReturnDate.Text.Length == 0)
            //{
            //    isValid = false;
            //    //sb.Append(Environment.NewLine + "Please Enter Return Date");
            //    MessageBox.Show("Please Enter Return Date");
            //}

            if (txtSource.Text.Length == 0)
            {
                isValid = false;
               sb.Append("\nPlease Enter Source");
            }

            if (txtDestination.Text.Length == 0)
            {
                isValid = false;
                sb.Append("\nPlease Enter Destination");
            }
            if (!isValid)
            {
                throw new Exception(sb.ToString());
            }

            return isValid;
        }

        //hyperlink event for login window
        private void Hyperlink_Login(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            AdminLogin adminLogin = new AdminLogin();
            adminLogin.Show();
            this.Close();
        }

        //hyperlink event for view ticket window
        private void Hyperlink_ViewTicket(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            ViewTicket viewTicket = new ViewTicket();
            viewTicket.Show();
        }


        //button click event for search flight 
        public void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Validation())
                {

                   flights = FlightBL.ViewFlightsBL(txtSource.Text, txtDestination.Text);
                    dgFlight.ItemsSource = flights;
                    dgFlight.Visibility = Visibility.Visible;
                   
                    
                }
             }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //private void btnAdminLogin_Click(object sender, RoutedEventArgs e)
        //{
        //    AdminLogin adminLogin = new AdminLogin();
        //    adminLogin.Show();
        //    this.Close();
        //}

        //button click event for book ticket
        private void BtnBook_Click(object sender, RoutedEventArgs e)
        {
            BookTicket home = new BookTicket();
            home.DataContext = flights;
            home.dpJourneyDate.Text = dpTravelDate.Text; 
            home.Show();
            this.Close();
        }

        //hyperlink event for contact us window
        private void Hyperlink_ContactUs(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            ContactUs contactUs = new ContactUs();
            contactUs.Show();
            this.Close();

        }

        //hyperlink event for about us window
        private void Hyperlink_AboutUs(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            AboutUs aboutUs = new AboutUs();
            aboutUs.Show();
            this.Close();

        }
    }
}
