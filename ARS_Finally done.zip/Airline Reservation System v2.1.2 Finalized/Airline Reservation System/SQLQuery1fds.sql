﻿select * from airline.reservation
select * from airline.flights
select * from airline.FlightClass
Select fare from airline.FlightClass where Class='First Class'
exec sp_help 'airline.USP_RESERVATIONINSERT'
exec sp_help 'airline.reservation'